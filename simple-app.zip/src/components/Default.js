import React, { Component } from 'react';

class Default extends Component {
    render() {
        return (
            <div>
                <h3>Ini Halaman Default</h3>
            </div>
        );
    }
}

export default Default;